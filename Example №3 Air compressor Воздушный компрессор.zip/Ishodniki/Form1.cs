﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form

       
    {
        // объявляем объект
        compressor test = new compressor();

        static int NNNN = 0;
        static int Count_s = 0; 
     public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            chart1.Series["test"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine; //
                  // очищаем график

            foreach (var series in chart1.Series)
            {
                series.Points.Clear();
            }

            //генератор случайного цвета 
            
            Random rand = new Random();


            Color color1 = Color.FromArgb(rand.Next(256),
                                         rand.Next(256),
                                         rand.Next(256));
            Color color2 = Color.FromArgb(rand.Next(256),
                                         rand.Next(256),
                                         rand.Next(256));
            Color color3 = Color.FromArgb(rand.Next(256),
                                         rand.Next(256),
                                         rand.Next(256));
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            listBox4.Items.Clear();
            listBox5.Items.Clear();
           
            listBox1.ForeColor = color1;
            listBox2.ForeColor = color2;
            listBox3.ForeColor = color3;
            listBox4.ForeColor = color1;
            listBox5.ForeColor = color2;
    
            NNNN++;

              label6.Text = "итерация № " + NNNN.ToString();


            listBox2.Items.Add("Test step №" + NNNN.ToString() + " for Q1 =");
            listBox2.Items.Add("-----------------------");

            listBox3.Items.Add("Test step №" + NNNN.ToString() + " for Q2=");
            listBox3.Items.Add("-----------------------");

            listBox4.Items.Add("Test step №" + NNNN.ToString() + " for Q3=");
            listBox4.Items.Add("-----------------------");

            for (int i = 1; i < 64; i++)
            {

                bool Triger_1 = checkBox1.Checked; // читаем клапаны
                bool Triger_2 = checkBox2.Checked;
                bool Triger_3 = checkBox3.Checked;
                test.Iteracia(Triger_1, Triger_2,Triger_3);
               
                listBox1.Items.Add("i=" + i.ToString() + " P in  =" + test.Davlenie_v_balone.ToString());

                listBox2.Items.Add("i=" + i.ToString() + " Q1 = " + test.Q1.ToString());
                listBox3.Items.Add("i=" + i.ToString() + " Q2 = " + test.Q2.ToString());
                listBox4.Items.Add("i=" + i.ToString() + " Q3 = " + test.Q3.ToString());

                chart1.Series["test"].Points.AddXY((double)i, (double)test.Davlenie_v_balone);
                if (test.Predohranitel==200)
                {
                    chart1.Series["test1"].Points.AddXY((double)i, (double)test.Davlenie_v_balone); // ставим отметки о срабатывание
                    listBox5.Items.Add("i=" + i.ToString() + " Klapan =" + test.Predohranitel.ToString());

                }

            }



        }




        // разное  , потом убрать

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void listBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            NNNN++;
            Count_s++;
            textBox6.Text = NNNN.ToString() + " секунд"; // счетчик
            SystemSounds.Beep.Play(); // прошла секунда

            bool Triger_1 = checkBox6.Checked; // читаем клапаны
            bool Triger_2 = checkBox5.Checked;
            bool Triger_3 = checkBox4.Checked;
            //чтение вкл выкл компрессора
            if (checkBox7.Checked)
            {
                test.Q_kompressora = 100; // компрессор включен
            }
            else
                {
                 test.Q_kompressora = 0; // компрессор выключен

                }
            
            test.Iteracia(Triger_1, Triger_2, Triger_3); // считаем

            textBox1.Text= test.Q1.ToString("F");
            textBox2.Text = test.Q2.ToString("F");
            textBox3.Text = test.Q3.ToString("F");
            textBox4.Text = test.Davlenie_v_balone.ToString("F")+" Бар";

            chart2.Series["test"].Points.AddXY(NNNN, test.Davlenie_v_balone);
            if (test.Predohranitel == 200)
                 {
                   // chart2.Series["test1"].Points.AddXY(NNNN, test.Davlenie_v_balone); // ставим отметки о срабатывание
                    textBox5.BackColor = Color.Red;
                    textBox5.Text = "On";
                SystemSounds.Beep.Play();

            }
            else
                {

                    textBox5.BackColor = Color.Green;
                    textBox5.Text = "Off";
                 }
            chart2.Update(); // обновляем график
          
            if (Count_s >= 20) // если расчет длинный , смещаем график
            {

                chart2.Series["test"].Points.RemoveAt(0);
                //chart2.Series["test1"].Points.RemoveAt(0);
                Count_s = 0;

            }
       
        }
        
        private void button2_Click(object sender, EventArgs e) //кнопка старт
        {
            if (button2.Text == "Stop")
            {
                button2.Text = "Start";

                timer1.Enabled = false;
                NNNN = 0;
                Count_s = 0;
             

            }
            else // момент запуска счета
            {
                button2.Text = "Stop";
             
                timer1.Enabled = true;
              }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e) // reset 
        {
        


        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
