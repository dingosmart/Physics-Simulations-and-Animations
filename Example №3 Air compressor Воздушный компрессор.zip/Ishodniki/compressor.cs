﻿namespace WindowsFormsApp5
{

    public class compressor {

    

        //описание полей 
        public double V_balona { set; get; }
        public double Q_kompressora { set; get; }
        public double Q1 { set; get; }
        public double Q2 { set; get; }
        public double Q3 { set; get; }

        public double S1 { set; get; } // сечения трубопроводов
        public double S2 { set; get; }
        public double S3 { set; get; }

        public double  Predohranitel { set; get; } // 33 бара
        public bool Prefohranitel_status { set; get; } 
        public double V_Vozduha_v_balone { set; get; }
        public double Davlenie_v_balone { set; get; }
        public double Balanse_obemov{ set; get; }


        // конструктор

        public compressor()
        {
            Prefohranitel_status = false;
            S1=0.8;
            S2 = 1.0;
            S3 = 0.5;
            V_balona = 50;
            Davlenie_v_balone = 0;
            V_Vozduha_v_balone = V_balona; // 50 литров
            Q_kompressora = 100;
            Predohranitel = 200;
            Balanse_obemov = 0;


        }

        public void Iteracia(bool F1, bool F2, bool F3)

        {
            //элементы рассчета

            //давление воздуха в балоне
            Davlenie_v_balone = V_Vozduha_v_balone / V_balona;
            V_Vozduha_v_balone = V_Vozduha_v_balone + Balanse_obemov;
            if (F1) // клапан 1 открыт
            {
                Q1 = S1 * Davlenie_v_balone;
            }
            else
            {
                Q1 = 0; // закрыт
            }

            if (F2) // клапан 2 открыт
            {
                Q2 = S2 * Davlenie_v_balone;
            }
            else
            {
                Q2 = 0; // закрыт
            }
            if (F3) // клапан 3 открыт
            {
                Q3 = S3 * Davlenie_v_balone;
            }
            else
            {
                Q3 = 0;  // закрыт
            }
            // определение срабатывания предохранительного клапана
            if (Davlenie_v_balone >= 33)
            {
                Predohranitel = 200; // надо потом сделать индикатор на переменную
            }
            else
            {
                Predohranitel = 0;
            }

            Balanse_obemov = Q_kompressora - Q1 - Q2 - Q3-Predohranitel;

           // V_Vozduha_v_balone = V_Vozduha_v_balone + Balanse_obemov;



        }
    }



}
