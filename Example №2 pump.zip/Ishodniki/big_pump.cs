﻿namespace WindowsFormsApp6
{
    using System.Windows.Forms;

    public class Big_pump
    {
        //описание полей 
        public double Q_nasosa_naminal { set; get; } // расход насоса по паспарту
        public double Zadviska { set; get; } // положение задвижки
        public double Q_nasosa_raschetnoe { set; get; } 
        public double P_min { set; get; }
        public double D_Tr { set; get; }
        public double lambda { set; get; } // кинетическая вязкость
        public double Plotnost_vody { set; get; }
        public double H1 { set; get; }
        public double H2 { set; get; } // высота размещения второго над насосом
        public double A{ set; get; } //ширина
        public double B { set; get; } // высота
        public double C { set; get; } // глубина
        public double V_balona { set; get; }  // объем балона
        public double V_balona_ost { set; get; }
        public double V_balona_pol { set; get; }
        public double skorost_vody_v_trube { set; get; }  // V2 рассчитываем из расходка
        public double P_atmosfernoe { set; get; } // давление атмосферное
        public double G { set; get; } // ускорение свободного падения
        public double P_vsasivania { get; set; }
        public double P_nagnetania { get; set; }
        public double H3{ set; get; } // высота размещения второго над насосом


        public Big_pump()   // конструктор
        {
            /*
            Q_nasosa_naminal = 0.240;
            Zadviska = 0;
            Q_nasosa_raschetnoe =(1-Zadviska)*Q_nasosa_naminal;
            P_min = 30000;               ;
            D_Tr = 0.71;
            Plotnost_vody = 1000;
            V_balona = 50;
            H1 =0;
            H2 = 5;
           
            V_balona = 50;
            skorost_vody_v_trube = 4 * Q_nasosa_raschetnoe/ (3.14*D_Tr*D_Tr);
            P_atmosfernoe = 1.1; //в паскалях
            G = 9.81;
            P_vsasivania =P_atmosfernoe-H1 * Plotnost_vody * G - Plotnost_vody * skorost_vody_v_trube * skorost_vody_v_trube / 2;
            P_nagnetania =P_atmosfernoe+ H2 * Plotnost_vody * G - Plotnost_vody * skorost_vody_v_trube * skorost_vody_v_trube / 2;
            V_balona_ost = V_balona - Q_nasosa_raschetnoe;
            V_balona_pol = V_balona - V_balona_ost;
            H3 = 5-H1;
              */
            
        }
        public void set_to_zero()
        {
            Q_nasosa_naminal = 0;
            Zadviska = 0;
            Q_nasosa_raschetnoe = (1 - Zadviska) * Q_nasosa_naminal;
            P_min =-0.3;
            D_Tr = 0.12;
            G = 9.81;
            Plotnost_vody = 1000;
            V_balona_ost = 50; // остаток воды в первом баке
            H1 = 5 - V_balona_ost / 10; // высота для первого бака
            H2 = 5; // возвышение насоса - жидкость вылевается в атмосферу !!!
            H3 = 5 - H1;  // высота воды во втором баке
            V_balona = 50; // объем балона

            // skorost_vody_v_trube = 4 * Q_nasosa_raschetnoe / (3.14 * D_Tr * D_Tr);
            skorost_vody_v_trube = 0;
            P_atmosfernoe =101325 ; 
            G = 9.81;
            P_vsasivania = (P_atmosfernoe - H1 * Plotnost_vody * G - Plotnost_vody * skorost_vody_v_trube * skorost_vody_v_trube / 2)/100000;
            //P_nagnetania = (P_atmosfernoe +H2 * Plotnost_vody * G - Plotnost_vody * skorost_vody_v_trube * skorost_vody_v_trube / 2) /100000;
            P_nagnetania = 0; // !!! из условия , что в начальный момент в трубе нет воды , если в трубе есть вода, то считаем по формуле которая содержится в коменте выше

             
        }
        public void Iteracia(double ZZ)

        {            
            Zadviska = ZZ;
            Q_nasosa_raschetnoe = (1 - Zadviska) * Q_nasosa_naminal; // реализация клапана 
            double D_Tr_1 =  D_Tr; 
            skorost_vody_v_trube = (4 * Q_nasosa_raschetnoe) / (3.14 * D_Tr_1 * D_Tr_1);
            H1 = 5 - V_balona_ost / 10;
            H2 = 5;
            H3 = 5 - H1;
            P_vsasivania = (P_atmosfernoe - H1 * Plotnost_vody * G - Plotnost_vody * skorost_vody_v_trube * skorost_vody_v_trube / 2) / 100000;
            P_nagnetania = (P_atmosfernoe +H2 * Plotnost_vody * G - Plotnost_vody * skorost_vody_v_trube * skorost_vody_v_trube / 2) / 100000;
            V_balona_ost = V_balona_ost - Q_nasosa_raschetnoe;
            V_balona_pol = V_balona - V_balona_ost;
              



        }

    }
    }
