﻿using System;
using System.Windows.Forms;
using System.Media;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    { //Объявляем объект

        Big_pump test = new Big_pump(); //насос

        static int NNNN = 0;
        static int Count_s = 0;
        public bool Flag_real_time=true;

        public Form1()
        {
            InitializeComponent();
            textBox1.Text = "0";
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            chart1.Series["PVS"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            chart2.Series["NAG"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;


            foreach (var series in chart1.Series)
            {
                series.Points.Clear();
            }
            foreach (var series in chart2.Series)
            {
                series.Points.Clear();
            }


            NNNN++;
            label8.Text = NNNN.ToString();

            listBox1.Items.Add("Test step №" + NNNN.ToString("0','000"));
            listBox1.Items.Add("-----------------------");

          
            test.set_to_zero();

            chart1.Series["PVS"].Points.AddXY((double)0, test.P_vsasivania);
            chart2.Series["NAG"].Points.AddXY((double)0, test.P_nagnetania);

            double Zz = Convert.ToDouble(textBox1.Text.ToString());
            listBox1.Items.Add("i=" + "0" + " P vs  =" + test.P_vsasivania.ToString());
            listBox2.Items.Add("i=" + "0" + " P nag =" + test.P_nagnetania.ToString());
            listBox3.Items.Add("i=" + "0" + " H1  =" + test.H1.ToString());
            listBox4.Items.Add("i=" + "0" + " H2  =" + test.H3.ToString());
            listBox5.Items.Add("i=" + "0" + " V1  =" + test.V_balona_ost.ToString());
            listBox6.Items.Add("i=" + "0" + " V2  =" + test.V_balona_pol.ToString());


            for (int i =1 ; i < 300; i++)
            {
                test.Q_nasosa_naminal = 0.170;
                test.Iteracia(0);

               if (test.P_vsasivania < -0.3) {
                    MessageBox.Show(" Достигнуто предельное значение давления всасывания  -0.3 Бара ");
                    break;
                }
              
                listBox1.Items.Add("i=" + i.ToString() + " P vs  =" + test.P_vsasivania.ToString());
                listBox2.Items.Add("i=" + i.ToString() + " P nag =" + test.P_nagnetania.ToString());
                listBox3.Items.Add("i=" + i.ToString() + " H1  =" + test.H1.ToString());
                listBox4.Items.Add("i=" + i.ToString() + " H2  =" + test.H3.ToString());
                listBox5.Items.Add("i=" + i.ToString() + " V1  =" + test.V_balona_ost.ToString());
                listBox6.Items.Add("i=" + i.ToString() + " V2  =" + test.V_balona_pol.ToString());


                chart1.Series["PVS"].Points.AddXY((double)i, test.P_vsasivania);
                chart2.Series["NAG"].Points.AddXY((double)i, test.P_nagnetania);
              
               
               
            }

        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void tabPage4_Click(object sender, EventArgs e) // для 4 закладки realtime emulation
        {
            test.set_to_zero();

            NNNN = 0;
            label11.Text = "0";
            chart3.Series["test3"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            chart4.Series["test4"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;



           // chart3.Series["test3"].Points.AddXY((double)0, test.P_vsasivania);
            //chart4.Series["test4"].Points.AddXY((double)0, test.P_nagnetania);
        }
        private void button3_Click(object sender, EventArgs e) // кнопка ресет realtime
        {
            test.set_to_zero();
            trackBar1.Value = 0;
            SystemSounds.Beep.Play();
            NNNN = 0;
            Count_s = 0;
            trackBar1.Value = 0;
            label11.Text = "0";
            MessageBox.Show("Система  сброшена к нулевым значениям, можно запускать");
            statusStrip1.Text = "Система  сброшена к нулевым значениям, можно запускать ";
            button2.Text = "Start";
            foreach (var series in chart3.Series)
            {
                series.Points.Clear();
            }
            foreach (var series in chart4.Series)
            {
                series.Points.Clear();
            }

           // chart3.Series["test3"].Points.AddXY((double)0, test.P_vsasivania);
            //chart4.Series["test4"].Points.AddXY((double)0, test.P_nagnetania);


        }

        private void button2_Click(object sender, EventArgs e)
        {
            


            if (button2.Text == "Stop")
            {
                button2.Text = "Start";
                button3.Visible = true;
                timer1.Enabled = false;
                NNNN = 0;
                Count_s = 0;


            }
            else
            {
                button2.Text = "Stop";

                foreach (var series in chart3.Series)
                {
                    series.Points.Clear();
                }
                foreach (var series in chart4.Series)
                {
                    series.Points.Clear();
                }
                
                timer1.Enabled = true;
                button3.Visible = false;

            }
        }
    
        private void timer1_Tick(object sender, EventArgs e)
        {
         
            NNNN ++;
            Count_s++;
            label11.Text = NNNN.ToString();

            SystemSounds.Beep.Play(); // прошла секунда

            double Zz = Convert.ToDouble(trackBar1.Value.ToString()) /10;
            if (checkBox1.Checked == true) // проверяем насос
                    {
                        // если насос включен 
                        test.Q_nasosa_naminal = 0.170;
                         statusStrip1.Text = "Насос включён ";
            }
            else
                    {
                        // если насос выключен
                        test.Q_nasosa_naminal = 0;
                 statusStrip1.Text = "Насос выключен ";
            }

        
            test.Iteracia(Zz);
            textBox5.Text = test.Q_nasosa_raschetnoe.ToString();
            textBox6.Text = test.P_vsasivania.ToString("F")+ " Бар";
            textBox7.Text = test.P_nagnetania.ToString("F")+ " Бар";
           
            toolStripStatusLabel4.Text= test.Q_nasosa_raschetnoe.ToString()+" литров";

            progressBar1.Value = Convert.ToInt32(test.H1 * 100);
            toolStripProgressBar1.Value= Convert.ToInt32(test.H1 * 100);
            textBox3.Text = test.H1.ToString("F")+" литров";
            progressBar2.Value = Convert.ToInt32(test.H3 * 100);
            toolStripProgressBar2.Value = Convert.ToInt32(test.H3 * 100);
            textBox4.Text = test.H3.ToString("F") + " литров";
                chart3.Series["test3"].Points.AddXY(NNNN, test.P_vsasivania);
                chart4.Series["test4"].Points.AddXY(NNNN, test.P_nagnetania);
            chart3.Update();
            chart4.Update();
            if (test.P_vsasivania < -0.3)
            {
                button2.Text = "Start";
                button3.Visible = true;
              
                notifyIcon1.Visible = true;
                notifyIcon1.Text = " Предельное значение давления всасывания  -0.3 Бара ";
                statusStrip1.Text = "Предельное значение давления всасывания  -0.3 Бара ";


                timer1.Dispose();
                 MessageBox.Show(" Достигнуто предельное значение давления всасывания  -0.3 Бара ");
            }

            if (Count_s>=40) {
               
                chart3.Series["test3"].Points.RemoveAt(0);
                chart4.Series["test4"].Points.RemoveAt(0);
                Count_s = 0;

            }


        }

        

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            textBox2.Text = trackBar1.Value.ToString();

        }

        private void chart4_Click(object sender, EventArgs e)
        {

        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void progressBar2_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }
    }
}
    
