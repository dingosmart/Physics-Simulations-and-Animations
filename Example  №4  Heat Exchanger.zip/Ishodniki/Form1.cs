﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        //Объявляем объект

        kodishen test = new kodishen (); // по умолчанию зададим 10 градусов тепла
                                  
        
        
        static int NNNN = 0;
        static int Count_s = 0;


        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // обнуляем графики
            chart1.Series["test"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine; //внутри кандея

            foreach (var series in chart1.Series)
            {
                series.Points.Clear();
            }
            
            //генератор случайного цвета 
            
            Random rand = new Random();
            Color color1 = Color.FromArgb(rand.Next(256),
                                         rand.Next(256),
                                         rand.Next(256));
            Color color2 = Color.FromArgb(rand.Next(256),
                                         rand.Next(256),
                                         rand.Next(256));
            Color color3 = Color.FromArgb(rand.Next(256),
                                         rand.Next(256),
                                         rand.Next(256));
            listBox1.Items.Clear();
            
            listBox1.ForeColor = color1;
            

            NNNN++;
            
            label7.Text = "итерация № " + NNNN.ToString();


            listBox1.Items.Add("Test step №" + NNNN.ToString() + " for T kod5=" );
            listBox1.Items.Add("-----------------------");



            string S1 = textBox1.Text.ToString();// читаем значения температуры
            string S2 = textBox2.Text.ToString();
            double a1 = Convert.ToDouble(S1);
            double a2 = Convert.ToDouble(S2);
           
            test.reset_to_zero(a1,a2); // сбрасываем на ноль данные рассчета



            double Triger1;
            if (checkBox1.Checked) {
                Triger1 = 1;
            }
            else
            { Triger1 = 0; }

            double Triger2;
            if (checkBox1.Checked)
            {
                Triger2 = 1;
            }
            else
            {
                Triger2 = 0;
            }           

            for (int i =0; i < 34; i++)
            {
               test.Iteracia(a1,a2,Triger1, Triger2);

               
                listBox1.Items.Add("  i= " + i.ToString() + " T kon= " + test.T_kondei_In.ToString() );
                              
                chart1.Series["test"].Points.AddXY((double)i, (double)test.T_kondei_In);
               
            }
         }
        

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }
        private void chart1_Click(object sender, EventArgs e)
        {
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            //textBox1.Text = "30";
          //  textBox2.Text = "10";
        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            NNNN++;
            Count_s++;
           label1.Text = NNNN.ToString() + " секунд"; // счетчик
            SystemSounds.Beep.Play(); // прошла секунда

            // читаем значения из тригеров и строк ввода

            // Сделано так, что бы потом можно было преобразовать интерфейс на расчет любых объемов
            double Triger1;
       
            if (checkBox3.Checked)
            {
                Triger1 = 1; // входящий объем масла 1 литр
            }
            else
            { Triger1 = 0; }

            double Triger2; // преобразование Bool  в объемное значение
            if (checkBox4.Checked)
            {
                Triger2 = 1; // входящий объем воды 1 литр 
            }
            else
            {
                Triger2 = 0;
            }
            string S1 = textBox3.Text.ToString();// читаем значения температуры
            string S2 = textBox4.Text.ToString();
            double a1 = Convert.ToDouble(S1);
            double a2 = Convert.ToDouble(S2);

           

            test.Iteracia(a1,a2,Triger1, Triger2);
            chart2.Series["test"].Points.AddXY(NNNN, test.T_kondei_In);
            textBox5.Text = test.T_kondei_In.ToString("F") + " Град.";

            chart2.Update(); // обновляем график

            if (Count_s >= 20) // если расчет длинный , смещаем график
            {

                chart2.Series["test"].Points.RemoveAt(0);
                
                Count_s = 0;

            }



        }

        private void button2_Click(object sender, EventArgs e)//кнопка старт
        {

            if (button2.Text == "Stop")
            {
                button2.Text = "Start";

                timer1.Enabled = false;
                NNNN = 0;
                Count_s = 0;


            }
            else // момент запуска счета
            {
                button2.Text = "Stop";

             
                

                // инициализируем , надо потом написать специальный конструктор к объекту

                if (checkBox3.Checked)
                {
                    test.V_vodu_in = 1; // входящий объем масла 1 литр
                   
                }
                else
                { test.V_vodu_in = 0;
                  
                }

               
                if (checkBox4.Checked)
                {

                    test.V_masla_in = 1; // входящий объем воды 1 литр 
                   
                }
                else
                {
                    test.V_masla_in = 0;
                    
                }

                string S1 = textBox3.Text.ToString();// читаем значения температуры
                string S2 = textBox4.Text.ToString();// надо будет сделать ползунок , как в других задачах
                double a1 = Convert.ToDouble(S1);
                double a2 = Convert.ToDouble(S2);

                test.reset_to_zero(a1,a2); // обнуляем 

                foreach (var series in chart2.Series) // очистка графика
                {
                    series.Points.Clear();
                }
                timer1.Enabled = true;
            }
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void tabPage4_Click(object sender, EventArgs e)
        {
            string S1 = textBox3.Text.ToString();// читаем значения температуры
            string S2 = textBox4.Text.ToString();
            double a1 = Convert.ToDouble(S1);
            double a2 = Convert.ToDouble(S2);
            foreach (var series in chart2.Series)
            {
                series.Points.Clear();
            }
            // test.reset_to_zero(a1, a2); // сбрасываем на ноль данные рассчета
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void chart2_Click(object sender, EventArgs e)
        {

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
