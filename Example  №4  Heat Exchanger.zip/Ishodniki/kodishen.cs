﻿namespace WindowsFormsApp4
{
    /// <summary>
    ///  Вторая задача с масленным охладителем
    /// </summary>

    public class kodishen
    {   
        
        // поля объекта 
        public double T_masla_in { get; set; }
        public double T_voda_in { get; set; }
        public double V_masla_in { get; set; }// объемный расход масла 
        public double V_vodu_in { get; set; } // объемный воды

        public double T_kondei_In { get; set; } // Температура внутри кандея
       
        public double C_masla { get; set; } // Соотношение теплоемкость масла к воде , можно изменять на плотность других сред , а можно сделать константой
        public double V_masla_kondei { get; set; }// объем масла в кандее
        public double V_vodu_kondei { get; set; } // объем воды в кондее


        public double T_masla_out { get; set; }
        public double T_voda_out { get; set; }
        /// <summary>
        ///  Если принять , что клапана простые , то надо лишь логическую переменную  
        ///  Задвижка 1 , задвижка 2
        /// </summary>
        public bool triger_1 { get; set; } // клапан масла
        public bool triger_2 { get; set; } // клапан воды 

        /// <summary>
        ///  Исходим из посыла , что энергия у нас сохраняется 
        /// </summary>

        public double E_all { get; set; } // Сумарный баланс энергий
        public double E_vt { get; set; } //Закачиваемая энергия
        public double E_vitek { get; set; } //Сбрасываемая энергия

        public kodishen()
        {    // конструктор

            triger_1 = false; // клапан закрыт
            triger_2 = false; // клапан закрыт
            V_masla_in = 0; // клапан  масла закрыт
            V_vodu_in = 0; // клапан  воды  закрыт
            V_masla_kondei = 5; // постоянный объем
            V_vodu_kondei = 7; // постоянный объем
            C_masla = 1.3; // относительная теплоемкость

        }

        public void reset_to_zero(double X, double Y)
        {
            T_masla_in = X;
            T_voda_in = Y;
            T_kondei_In = Y;
                       // объем масла задан в конструкторе
                      // обем воды в кандее задан в конструкторе 
        
            V_masla_in = 0; // клапан  масла закрыт
            V_vodu_in = 0; // клапан  воды  закрыт
            V_masla_kondei = 5; // постоянный объем
            V_vodu_kondei = 7; // постоянный объем
            C_masla = 1.3; // относительная теплоемкость
                        
          
            E_vt = T_voda_in * V_vodu_in + T_masla_in*C_masla * V_masla_in;

            E_vitek = V_vodu_in * T_kondei_In + V_masla_in * C_masla * T_kondei_In;

            E_all = T_kondei_In * (V_masla_kondei * C_masla + V_vodu_kondei); // инициализация общей энергии на нулевом ш



        }
        public void Iteracia(double X, double Y, double Vms, double Vvod)
        {
            /// <summary>
            /// НА ВХОДЕ ПОДАЕМ ТЕМПЕРАТУРУ  масла , температуру воды, состояние клапанов
            /// </summary>

            T_masla_in = X;
            T_voda_in = Y;
            V_masla_in = Vms; ;
            V_vodu_in = Vvod;
            // 1.логика


            // 2.рассчет энергий

            //E_all = T_kondei_In * (V_masla_kondei * C_masla + V_vodu_kondei); // n-1 шаг
            E_all = E_all - E_vitek + E_vt;
            T_kondei_In = E_all / (V_masla_kondei * C_masla + V_vodu_kondei);

            E_vt = T_voda_in * V_vodu_in + T_masla_in * C_masla * V_masla_in;// втекающия энергия 0 вначале шаг N

            E_vitek = V_vodu_in * T_kondei_In + V_masla_in * C_masla * T_kondei_In; // вытеккющая энергия  шаг N

            // E_all = T_kondei_In * (V_masla_kondei * C_masla + V_vodu_kondei);




            // 3. общая формула
            // T_masla_out = T_masla_in -T_kondei_In;
            //  T_voda_out = T_voda_in-T_kondei_In;


        }

    }
}
